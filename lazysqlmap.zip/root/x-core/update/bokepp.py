import os,sys,time
os.system('clear')
print ("")
bokep = """\033[92m   ██████╗  ██████╗ ██╗  ██╗███████╗██████╗  
   ██╔══██╗██╔═══██╗██║ ██╔╝██╔════╝██╔══██╗ 
   ██████╔╝██║   ██║█████╔╝ █████╗  ██████╔╝ 
   ██╔══██╗██║   ██║██╔═██╗ ██╔══╝  ██╔═══╝  
   ██████╔╝╚██████╔╝██║  ██╗███████╗██║     
   ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝ \033[97mv 1.0   
"""
#Kontol Bapak Kau Pecah
#coding Mr.Zck18
kontol = """  \033[95m╔════════════════════════════════════════╗
  \033[95m║ \033[94mAuthor   \033[97m● \033[93mMr.Zck18\033[95m                    ║
  \033[95m║ \033[94mTeam     \033[97m● \033[92mX-core ~ \033[91mindonesi\033[97man necoder\033[95m ║
  \033[95m║ \033[94mWhatsapp \033[97m● \033[93m+62 852-5869-1379\033[95m           ║
  \033[95m║ \033[94mThanks to\033[97m● \033[93mMr¿?                        \033[95m║
  \033[95m╚════════════════════════════════════════╝
"""
def jalan(ilham):
	for e in ilham:
	   sys.stdout.write(e)
	   sys.stdout.flush()
	   time.sleep (0.1)
menu = """  ╔══
  ║
  ║ \033[91m[\033[92m1\033[91m]\033[93m.\033[97mIndonesia
  \033[95m║ \033[91m[\033[92m2\033[91m]\033[93m.\033[97mKorea
  \033[95m║ \033[91m[\033[92m3\033[91m]\033[93m.\033[97mJapanese
  \033[95m║ \033[91m[\033[92m4\033[91m]\033[93m.\033[97mAmerica
  \033[95m║ \033[91m[\033[92m5\033[91m]\033[93m.\033[97mAsia
  \033[95m║ \033[91m[\033[92m6\033[91m]\033[93m.\033[97mAbout
  \033[95m║ \033[91m[\033[92m7\033[91m]\033[93m.\033[97mExit
  \033[95m║
  \033[95m╚══
"""
about = """
	Author   : Mr.Zck18
	Team     : X-core Indonesia Penetration
	Support  : indonesian Necoder
	Thanks to: All Member Indonesia Newbie Necoder
	Biarkan kami berkarya Tanpa Recode,
	Tolong Maklumi,Script Saya yang sangat
	jelek Sedunia
	saya sangat berterima kasih kepada
	seluruh Hacker,Cracker,Anonymouse
	seluruh indonesia.
"""
#time.sleep(3)
print (bokep)
print (kontol)

jalan("  \033[97mSelamat Datang Di Tools Mr.Zck18\n")
time.sleep(0.1)
jalan("  Tools Ini berisi Video Bokep\n")
time.sleep(0.1)
jalan("  Jangan Salahkan Author Jika kamu Sangek\n")
time.sleep(0.1)
jalan("  Terima Kasih Kepada \n")
time.sleep(0.1)
jalan("  Mr.¿? ~ /Mr.3MOC4R7 ~ Mr.b4nd!t\n")
time.sleep(0.1)
jalan("  All Member X-core Indonesian Penetration")
time.sleep(3)
os.system('clear')
print ("")
print (bokep)
print (kontol)
print (menu)
print ("  \033[97mSilahkan Pilih ")
print ("  \033[97m╭─\033[97m[\033[92mMr.Zck18\033[91m@\033[92mlocalhost\033[97m]")
pil = int(input("  ╰─\033[95m»\033[97m "))
if (pil == 1):
#	os.system('cd module')
#	os.system('mv indonesia.mp4 /sdcard')
	print ("  Silahkan Cek Di Memori Internal")
elif (pil == 2):
	os.system('cd module')
	os.system('mv korea.mp4 /sdcard')
	print ("  Silahkan Cek Di Memori Internal")
elif (pil == 3):
	os.system('cd module')
	os.system('mv japanese.mp4 /sdcard')
	print ("  Silahkan Cek Di Memori Internal")
elif (pil == 4):
	os.system('cd module')
	os.system('mv america.mp4 /sdcard')
	print ("  Silahkan Cek Di Memori Internal")
elif (pil == 5):
	os.system('cd module')
	os.system('mv asia.mp4 /sdcard')
	print ("  Silahkan Cek Di Memori Internal")
elif (pil == 6):
	print(about)
	time.sleep(5)
elif (pil == 7):
	os.system('toilet -f standard " bye-bye')
	os.system('sleep 3')
	os.system('exit')
else:
	print ("  Masukkan Dengan Benar")
	os.system("sleep 2")
	os.system("python bokep.py")
